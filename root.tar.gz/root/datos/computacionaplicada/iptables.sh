iptables -F
iptables -P INPUT DROP
iptables -P FORWARD DROP
######## DE SALIDA TODO PERMITIDO ##########
iptables -P OUTPUT ACCEPT
######## DE ENTRADA SOLO PERMITIREMOS 22,80,443 #########
iptables -A INPUT -i enp0s3 -p tcp --dport 22 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -o enp0s3 -p tcp --sport 22 -m state --state ESTABLISHED -j ACCEPT

iptables -A INPUT -i enp0s3 -p tcp --dport 80 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -o enp0s3 -p tcp --sport 80 -m state --state ESTABLISHED -j ACCEPT

iptables -A INPUT -i enp0s3 -p tcp --dport 443 -m state --state NEW,ESTABLISHED -j ACCEPT
iptables -A OUTPUT -o enp0s3 -p tcp --sport 443 -m state --state ESTABLISHED -j ACCEPT

######## SE PERMITE TODO LO LOCALHOST #########
iptables -I INPUT --jump ACCEPT --in-interface lo
iptables -I OUTPUT --jump ACCEPT --out-interface lo
###############################################
# POR SI QUISIERAMOS LOGEAR ALGO
# iptables -N LOGGING
#iptables -A INPUT -j LOGGING
#iptables -A OUTPUT -j LOGGING
#iptables -A LOGGING -m limit --limit 2/min -j LOG --log-prefix "TP IPTables-Dropped: " --log-level 4
#iptables -A LOGGING -j DROP
