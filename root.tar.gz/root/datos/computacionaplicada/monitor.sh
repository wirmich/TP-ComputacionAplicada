#!/bin/bash
LOGFINAL="/tmp/monitor.log"
DEMONIO=$1
rm -f ${LOGFINAL}
function ayuda(){
	echo "Como ejecutar este programa:"
	echo "	monitor.sh <demonio del servidor>"
	echo "	Monitoreo dicho proceso en la lista de tareas activas y si no lo encuentra envía un email"
	echo "o"
	echo "	monitor.sh -h"
	echo "	Muestra esta ayuda"
}

if [ "${DEMONIO}" = "-h" ];then
	ayuda
	exit 0 
fi
# verificar que tengamos solo 1 argumentos:
# fuente: https://linuxhint.com/check-the-number-of-arguments-in-bash/
if [ $# -ne 1 ]; then
	echo "El numero de argumentos no es correcto, deben ser 1"
	exit 1	
fi

STATUS=$(systemctl status ${DEMONIO} 1>/dev/null 2>/dev/null && echo Iniciado:OK || echo Iniciado:NOK)
echo "Status de ${DEMONIO} es:${STATUS}"
if [ "${STATUS}" = "Iniciado:OK" ];then
	exit 0
else
	echo "Status de ${DEMONIO} es:${STATUS}" | mail -s "monitor.log" root@localhost
	exit 1
fi

