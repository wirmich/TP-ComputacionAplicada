#!/bin/bash
/opt/tp/scripts/esLaborable.sh 2023-01-01
