#!/bin/bash
#
# 
LOGFINAL="/tmp/backup_full.log"
# el primer argumento será el directorio origen del backup 
# lo tomamos y le quitamos la diagonal final
ORIG=$(echo "$1" | sed 's/\/$//')
# el segundo argumento será el directorio destino
# lo tomamos y le quitamos la diagonal final
DEST=$(echo "$2" | sed 's/\/$//')
#
PART_CORRECTA="/u03"
#PART_CORRECTA="/dev/vda2"
#
# borrando log viejo
rm -f ${LOGFINAL}

function log(){
	#los argumentos del log los guardamos en un lugar
	FORMATO_FECHA=$(date +"%H:%M:%S")
	HACIENDO="$1"
	PASANDO="$2"  
	echo "${FORMATO_FECHA} - ${HACIENDO} | ${PASANDO}" >> ${LOGFINAL}
}
function sendlog(){
	#los argumentos del log los guardamos en un lugar
	cat ${LOGFINAL} | mail -s "backup_full.log" root@localhost && echo "Enviado OK" || echo "Enviado NOK"
}
function ayuda(){
	log "Dentro de la funcion ayuda" "iniciando mostrar ayuda"
	echo "Como ejecutar este programa:"
	echo "	backup_full.sh <directorio a respaldar origen> <directorio de guardar destino>"
	echo "	Comprime todos los archivos que se encuentren en el directorio origen (recursivamente) y los coloca en el directorio destino con un formato específico"
	echo "o"
	echo "	backup_full.sh -h"
	echo "	Muestra esta ayuda"
	log "Dentro de la funcion ayuda" "terminado de mostrar ayuda"
}

function formatea_nombre(){
	ORIG="$1"
	log "al	nombre original le vamos a" "quitar la primera / y las demás / las transformamos en _, y las mayusculas a minusculas y los puntos por guiones medios, luego le agregamos la extensión"
	ORIG_NOMBRE_FORMATO=$(echo $ORIG| sed 's/^\///' |tr '/' '_' | tr '[:upper:]' '[:lower:]'| tr '.' '-')"_bkp_"$(date +'%Y%m%d'".tar.gz")
	log "quedando:" "ORIGEN:${ORIG} ORIG_NOMBRE_FORMATO:${ORIG_NOMBRE_FORMATO}"
	echo ${ORIG_NOMBRE_FORMATO}
}

function comprime(){
	#arg1 = ORIGEN 
	#arg2 = DIR DESTINO
	ORIG="$1"
	DEST="$2"
	NOMBRE=$(formatea_nombre ${ORIG})
	log "Function comprime" "Ya tomamos los argumentos"
	#previamente durante el script ya se hicieron las validaciones entonces, hacemos
	log "Antes de generar el comprimido con" "tar czf ${DEST}/${NOMBRE} ${ORIG}"
	tar czf ${DEST}/${NOMBRE} ${ORIG} && echo "TAR OK" || echo "TAR NOK"
}
# Primero verificamos si alguno de los argumentos es un -h
# fuente: https://unix.stackexchange.com/questions/47584/in-a-bash-script-using-the-conditional-or-in-an-if-statement
if [ "$1" = "-h" ] || [ "$2" = "-h" ];then
	log "verificando si los argumentos son -h" "Llamar funcion de ayuda"
	ayuda
	log "mostrar la ayuda" "genera error tipo 0 es decir, sin error"
	exit 0 
fi
# verificar que tengamos solo 2 argumentos:
# fuente: https://linuxhint.com/check-the-number-of-arguments-in-bash/
if [ $# -ne 2 ]; then
	echo "El numero de argumentos no es correcto, deben ser 2"
	log "Dentro de if para verificar numero de argumentos" "Es diferente de 2 entonces me salgo"
	exit 1	
	log "He terminado de verificar si hay solo 2 arumentos" "Si hay solo 2"
fi


#verifcamos que los argumentos sean correctos, es decir sea un directorio origen y uno destino
#fuente: man stat
# -c  --format=FORMAT
# 	%F     file type
#
#
log "Vamos a verificar si ORIG y DEST son directorios" ""
ES_DIR_ORIG=$(stat -c%F ${ORIG})
ES_DIR_DEST=$(stat -c%F ${DEST})
if [ "$ES_DIR_ORIG" = "directorio" ];then
	log "Si ORIG es directorio" "Continuamos"
else
	log "Hubo un problema con ORIG, saliendo"
	exit 2
fi
if [ "$ES_DIR_DEST" = "directorio" ];then
	log "Si DEST es directorio" "Continuamos"
else
	log "Hubo un problema con DEST, saliendo"
	exit 3
fi

log "Vamos a verificar si ORIG y DEST son accesibles y existen"
EXISTE_ORIG=$(stat ${ORIG}/.. 1>/dev/null 2>&1 && echo OK || echo NOK)
if [ "${EXISTE_ORIG}" = "OK" ];then
	log "IF EXISTE_ORIG" "DEST existe y es accesible"
else
	log "IF EXISTE_ORIG" "Hubo un problema con DEST, saliendo"
fi
EXISTE_DEST=$(stat ${DEST}/.. 1>/dev/null 2>&1 && echo OK || echo NOK)
if [ "${EXISTE_DEST}" = "OK" ];then
	log "IF EXISTE_DEST" "DEST existe y es accesible"
else
	log "IF EXISTE_DEST" "Hubo un problema con DEST, saliendo"
fi
log "Verificando si DEST se encuentra en la partición correcta ${PART_CORRECTA}"
MNT_DEST=$(df -PH ${DEST} | tail -n+2 | awk '{print $1}')
if [ "${MNT_DEST}" = "${PART_CORRECTA}" ];then
	log "IF MNT_DEST" "DEST se encuentra en la partición correcta"
else
	log "IF MNT_DEST" "No se encuentra en la partición correcta, saliendo"
fi
STATUS_COMPRIME=$(comprime ${ORIG} ${DEST})
log "STATUS_COMPRIME" "${STATUS_COMPRIME}"
if [ "${MNT_DEST}" = "${PART_CORRECTA}" ];then
	log "IF MNT_DEST" "DEST se encuentra en la partición correcta"
else
	log "IF MNT_DEST" "No se encuentra en la partición correcta, saliendo"
fi
STATUS_COMPRIME=$(comprime ${ORIG} ${DEST})
log "Terminamos de comprimir con status:" "${STATUS_COMPRIME}"
log "Hay que instalar el mutt y cambiar la linea para enviar correo en lugar de desplegar estos status"
SENDLOG=$(sendlog)
if [ "${SENDLOG}" = "Enviado OK" ];then
	log "SENDLOG" "Mail enviado exitosamente"
else
	log "SENDLOG" "Mail no enviado"
fi
