#!/bin/bash
#http://servicios.infoleg.gob.ar/infolegInternet/anexos/170000-174999/174389/norma.htm
#https://www.lanacion.com.ar/feriados/2023/
#https://www.lanacion.com.ar/feriados/2024/
#esLaborable.sh
# 1 de enero: Año Nuevo:0101
#24 de marzo: Día Nacional de la Memoria por la Verdad y la Justicia:0324
# 2 de abril: Día del Veterano y de los Caídos en la Guerra de Malvinas.:0402
# 1º de mayo: Día del Trabajo.: 0501
# 25 de mayo: Día de la Revolución de Mayo.: 0525
# 20 de junio: Paso a la Inmortalidad del General D. Manuel Belgrano.:0620
# 9 de julio: Día de la Independencia.0709
# 8 de diciembre: Día de la Inmaculada Concepción de María:1208
# 25 de diciembre: Navidad:1225
### trasladables
# 17 de agosto: Paso a la Inmortalidad del General D. José de San Martín:cumplido el tercer lunes de ese mes 
# 12 de octubre: Día del Respeto a la Diversidad Cultural:cumplido el segundo lunes de ese mes
# 20 de noviembre: Día de la Soberanía Nacional:cumplido el cuarto lunes de ese mes.

#https://www.perfil.com/noticias/sociedad/el-vinculo-entre-las-fechas-del-carnaval-y-semana-santa-cual-es.phtml
# Lunes y Martes de Carnaval
# Jueves Santo
# Viernes Santo

#fuente: https://gist.github.com/ingmarioalberto/a547bf6f9a6166a27d0cd63c2ecaba41
function NDayOfMonth (){
# script to look for the N-th day of the month 
# for example: 
# The second Thursday of the February of 2024
# NDayOfMonth 2 3 2022 07
#		arg1: 1,2,3,4,5 (1st, 2nd, 3rd, 4th, 5th day of the month)
#		arg2: number for Day of the week (1=Sunday, 7=Saturday) 
#		arg3: Year in 4 digits
#		arg4: Month in 2 digits
# Firstly we need to get the weekday for the first day of the month 
	#won't validate anything... so be careful
	DM="$1"; 	WW="$2"; 	YYYY="$3"; 	mm="$4"	
	#R=$(ncal $mm $YYYY 2>/dev/null | tail -n+2 | head -n${WW} | tail -n1 | xargs | cut -d " " -f2- | cut -d " " -f"${DM}")
	R=$(cal $mm $YYYY 2>/dev/null| tail -n+2 | awk -v day="${WW}" '{print $day}' | tail -n+2 | xargs | cut -d " " -f${DM})
	echo "${R}"
}
YYYY=$(echo "$@" | cut -d "-" -f1)
MM=$(echo "$@"   | cut -d "-" -f2)
DD=$(echo "$@"   | cut -d "-" -f3)

MMDD="${MM}${DD}"
case ${MMDD} in
  "0101")
    echo "Año Nuevo:No laborable"
    exit
  ;;
  "0324")
    echo "Día Nacional de la Memoria por la Verdad y la Justicia:No laborable"
    exit
  ;;
  "0402")
    echo "Día del Veterano y de los Caídos en la Guerra de Malvinas:No laborable"
    exit
  ;;
  "0501")
    echo "1º de mayo: Día del Trabajo"
    exit
  ;;
  "0525")
    echo "Día de la Revolución de Mayo:No laborable"
    exit
  ;;
  "0620")
    echo "Paso a la Inmortalidad del General D. Manuel Belgrano:No laborable"
    exit
  ;;
  "0709")
    echo "Día de la Independencia:No laborable"
  	exit
  ;;
  "1208")
    echo "Día de la Inmaculada Concepción de María:No laborable"
    exit
  ;;
  "1225")
    echo "Mi cumpleaños y Navidad:No laborable"  
  	exit
  ;;
  *)
    #Verificar si es otra cosa como trasladable
    #Esto  no está funcionando...
    #TRAS0817=$(NDayOfMonth 3 2 ${YYYY} ${mm})
    #echo "TRAS0817:${TRAS0817}"
    #if [ "${TRAS0817}" == "${DD}" ]; then
    #   echo "Trasladable de 17/08, Paso a la Inmortalidad del General D. José de San Martín:No laborable" 
    #fi
    #TRAS1010=$(NDayOfMonth 2 2 ${YYYY} ${mm})
    #echo "TRAS1010:${TRAS1010}"
    #if [ "${TRAS1010}" == "${DD}" ]; then
    #   echo "Día del Respeto a la Diversidad Cultural:No laborable" 
    #fi
    #TRAS1120=$(NDayOfMonth 4 2 ${YYYY} ${mm})
    #echo "TRAS1120:${TRAS1120}"
    #if [ "${TRAS1120}" == "${DD}" ]; then
    #   echo "Día de la Soberanía Nacional:No laborable" 
    #fi
    echo "Es laborable"
    exit 0
    #Verificar si es otra cosa como Carnaval o Jueves/Viernes Santo
  ;;
esac
