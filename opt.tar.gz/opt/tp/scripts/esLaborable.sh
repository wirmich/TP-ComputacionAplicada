#!/bin/bash
# Determina si la fecha ingresada por parametro es un dia laborable
esLaborable(){
fecha="$1"
# Verifica si la fecha coincide con un dia no laborable en Argentina en 2023
case "$fecha" in
# Enero
"2023-01-01") echo "Es feriado: Ano Nuevo" ;;
# Febrero
"2023-02-20") echo "Es feriado: Carnaval";;
"2023-02-21") echo "Es feriado: Carnaval";;
# Marzo
"2023-03-24") echo "Es feriado: Dia Nacional de la Memoria por la Verdad y la
Justicia";;
# Abril
"2023-04-02") echo "Es feriado: Dia del Veterano y de los Caidos en la Guerra de
Malvinas";;
"2023-04-06") echo "Es feriado: Jueves Santo Festividad Cristiana";;
"2023-04-07") echo "Es feriado: Viernes Santo Festividad Cristiana";;
"2023-04-12") echo "Es feriado: Pascuas Judias";;
"2023-04-13") echo "Es feriado: Pascuas Judias";;
"2023-04-21") echo "Es feriado: Fiesta de la Ruptura del Ayuno del Sagrado Mes
de Ramadan";;
"2023-04-24") echo "Es feriado: Dia de accion por la tolerancia";;
# Mayo
"2023-05-01") echo "Es feriado: Dia del Trabajador";;
"2023-05-25") echo "Es feriado: Dia de la Revolucion de Mayo";;
"2023-0526") echo "Es feriado: Feriado Puente Turistico";;
# Junio
"2023-06-17") echo "Es feriado: Paso a la Inmortalidad del Gral. Don Martin
Guemes";;
"2023-06-19") echo "Es feriado: Feriado Puente Turistico";;
"2023-06-20") echo "Es feriado: Paso a la Inmortalidad del Gral. Manuel
Belgrano";;
"2023-06-28") echo "Es feriado: Fiesta del Sacrificio";;
# Julio
"2023-07-09") echo "Es feriado: Dia de la Independencia";;
"2023-07-19") echo "Es feriado: Ano Nuevo Islamico";;
# Agosto
"2023-08-21") echo "Es feriado: Paso a la Inmortalidad del Gral. Jose de San
Martin";;
# Septiembre
"2023-09-16") echo "Es feriado: Ano Nuevo Judio";;
"2023-09-17") echo "Es feriado: Ano Nuevo Judio";;
"2023-09-25") echo "Es feriado: Dia del Perdon";;
# Octubre
"2023-10-13") echo "Es feriado: Feriado Puente Turistico";;
"2023-10-16") echo "Es feriado: Dia del Respeto a la Diversidad Cultural";;
# Noviembre
"2023-11-20") echo "Es feriado: Dia de la Soberania Nacional";;
# Diciembre
"2023-12-08") echo "Es feriado: Inmaculada Concepcion de Maria";;
"2023-12-25") echo "Es feriado: Navidad";;
# Verificar si es fin de semana
-[06]-|-[07]-) echo "Es fin de semana";;
#Si es dia laborable
*) echo "Es dia laborable";;
esac
}
# Llamar a la funcion si se paso la fecha como parametro
if [ $# -eq 1 ]; then
esLaborable "$1"
fi
